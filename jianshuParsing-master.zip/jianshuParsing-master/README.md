# jianshuParsing
Swift爬取简书作者文章列表数据，正则匹配瀑布流展示
- HTTPS下载HTML源码，分析数据结构正则匹配列表数据，存入数组模型
- 自定义layout，瀑布流展示数据
- swift与WKWebView交互,注入js代码，达到隐藏、添加HTML元素等效果。
- [详细说明请移步简书](https://www.jianshu.com/p/fb209814ee9d)
